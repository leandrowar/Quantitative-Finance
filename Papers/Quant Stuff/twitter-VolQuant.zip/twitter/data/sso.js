window.YTD.sso.part0 = [
  {
    "singleSignOnMetaValues" : {
      "ssoId" : "114810898045683168230",
      "ssoEmail" : "urbanfitnesstlv@gmail.com",
      "associationMethodType" : "Login",
      "createdAt" : "2021-11-26T16:26:33.480Z"
    }
  }
]