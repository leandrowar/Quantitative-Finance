window.YTD.ageinfo.part0 = [
  {
    "ageMeta" : {
      "ageInfo" : {
        "age" : [
          "39"
        ],
        "birthDate" : "1982-06-27"
      }
    }
  }
]