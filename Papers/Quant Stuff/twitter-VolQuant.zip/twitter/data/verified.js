window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "1293505084484132864",
      "verified" : false
    }
  }
]