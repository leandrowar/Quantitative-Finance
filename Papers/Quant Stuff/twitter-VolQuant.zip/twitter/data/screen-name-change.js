window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "1293505084484132864",
      "screenNameChange" : {
        "changedAt" : "2020-08-28T04:31:14.000Z",
        "changedFrom" : "harel46317546",
        "changedTo" : "VolQuant"
      }
    }
  }
]