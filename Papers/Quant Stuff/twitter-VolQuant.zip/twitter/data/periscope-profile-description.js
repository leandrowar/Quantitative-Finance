window.YTD.periscope_profile_description.part0 = [
  {
    "periscopeProfileDescription" : {
      "bio" : "Quant PM. Global Volatility Trading. Python addict. Bloomberg Junkie. Amateur Boxer and boxing coach (RSB cert.) !No investment advice! Don't try this at home"
    }
  }
]