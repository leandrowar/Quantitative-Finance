window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "",
      "createdVia" : "",
      "username" : "VolQuant",
      "accountId" : "",
      "createdAt" : "",
      "accountDisplayName" : "Harel Jacobson"
    }
  }
]