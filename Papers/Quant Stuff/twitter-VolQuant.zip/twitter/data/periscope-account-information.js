window.YTD.periscope_account_information.part0 = [
  {
    "periscopeAccountInformation" : {
      "displayName" : "Harel Jacobson",
      "digitsId" : "",
      "username" : "VolQuant",
      "twitterId" : "1293505084484132864",
      "id" : "1zYKbnbAMAlKe",
      "twitterScreenName" : "VolQuant",
      "isTwitterUser" : true,
      "createdAt" : "2021-08-23T19:53:35.001928142Z"
    }
  }
]