window.YTD.saved_search.part0 = [
  {
    "savedSearch" : {
      "savedSearchId" : "1298903171553665024",
      "query" : "#VIX"
    }
  }
]