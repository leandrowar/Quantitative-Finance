window.YTD.lists_member.part0 = [
  {
    "userListInfo" : {
      "url" : "https://twitter.com/protoxrz/lists/1499064072125435905"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/0xslumber/lists/1498240592949784577"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/LuckyCats42/lists/1497950699702915078"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/binancefanboi/lists/1497630448901627906"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nithinrs/lists/1496915816109211650"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SolyomMark/lists/1496589616576708609"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/trip_solar/lists/1496492630615760899"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/dawnofanewera81/lists/1495801603625996289"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/STrading40/lists/1494462257589272577"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/aspergerbytrade/lists/1492101006901055498"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/AbhishekAnandMe/lists/1491602041285881859"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mcderphi/lists/1491464932277338116"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DVU1990/lists/1491290977461485571"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CfaRafal/lists/1490964122338533376"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Aezela1/lists/1490665640201539584"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/blinzka/lists/1490264006141128706"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/knwkrseeker/lists/1490120075038400518"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/GammaGlyp/lists/1490087272745680905"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/benmcdnld/lists/1489659015529472005"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Damiano36167790/lists/1488714657409945602"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DA11952274/lists/1488611649615544324"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Nikos_Papa_D/lists/1488384159512870912"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Cathie51662/lists/1488035017137831936"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/coinb73282/lists/1487987332179542022"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/AleksanderEde/lists/1486758080977199110"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/cilantromurphy1/lists/1486515768267313152"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Florian_MS/lists/1484845069245063173"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mehtahershey101/lists/1484572931602661376"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/sbn1970/lists/1483412171203784707"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Akash____Gupta/lists/1483403899730108416"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/goodlsjFX/lists/1483348112039358465"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/AlphaLeakOOR/lists/1483288761530261509"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/danilogalisteu/lists/1482905230127812608"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/esnoble/lists/1482301938595090432"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/cesposito/lists/1482193906464923653"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/quantfiction/lists/1480573173137608709"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Fin_Fallacies/lists/1479300230483001347"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/vikingfund/lists/1479281084332453895"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/asidesilva/lists/1479084255846318083"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/vamsTrader/lists/1478838629548138501"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/iesuslord/lists/1478521456598429699"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/obeserverji/lists/1478198123461701633"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/achadri99/lists/1477372011164979204"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Color_ado_color/lists/1477320732552187913"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BollingerBeans/lists/1476894086699302916"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/FiveThreeZer0/lists/1475871419233968290"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Garrechu/lists/1475296711765630977"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MinhToa53454612/lists/1474775600950702080"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/bhoomikaojha/lists/1473882537063710720"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Declan94058998/lists/1473618931692838914"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/zhtGHa0/lists/1473110071261290496"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ClarkKennedy16/lists/1473097414030540801"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/RobertH29713297/lists/1473089505548640260"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/weing_Gilgamesh/lists/1471564981942554635"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Space_Monkey777/lists/1471519265047998464"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/FellowTail/lists/1470528145887567874"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/morro_66/lists/1470234586755973121"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/JtrMurphy/lists/1469783333412519937"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/PigsFlyTwo/lists/1467910336237821954"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MinhToa53454612/lists/1467714238106210305"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ayushdxtiwari11/lists/1467665437630468104"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/dwierzba/lists/1467042532945059840"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/OldrichSmejkal/lists/1466730018600632322"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Alexand40973876/lists/1466088007581290503"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ShaowInSakura/lists/1465910224741535744"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ShaowInSakura/lists/1465910183649955848"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/EntropyDenier/lists/1465571469165879301"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/itchingpixels/lists/1465279777321934850"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/aTechOnAWheel/lists/1465210465789755393"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/alihobbalah/lists/1465000074094727182"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/O__Canada/lists/1464942957002469378"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/0xDipzy/lists/1464200471686516737"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Bas2032/lists/1463789843801116676"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Hitta71/lists/1463355009609781249"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/GammaGlyp/lists/1461855927045394435"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/gius931/lists/1461100972848168961"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/t1618/lists/1460751928208637955"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/quasar_bear/lists/1460053921263611904"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/IrrespBored/lists/1459470958708895746"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/EntropicEdge/lists/1459318002428567555"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/emrebalduk/lists/1459122311278350338"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/xbtcv/lists/1457613465988784131"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/YHRW80/lists/1457605569846644736"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ihemantd/lists/1457241220560740355"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/NgwenzaDumisani/lists/1456858264814170114"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/IEST18/lists/1455180988129103888"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/0xShire/lists/1454105210671013888"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/IAmTrickyEnough/lists/1453446652157693954"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/GarhNauti/lists/1453442895105560580"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/stanelake/lists/1451532361124958212"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/joaquimSampaio/lists/1450175714590924806"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/LIANGLEEE/lists/1449618852376023041"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DanielEvanSmith/lists/1448649456786698258"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MLippenstift/lists/1448645345156599810"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/sys_qed/lists/1448632727125872642"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/athenaeus/lists/1447718666070597635"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/skughered/lists/1446815997357404164"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nope_its_lily/lists/1445977120677797892"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Teco/lists/1445883589934125059"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nalgenie2/lists/1445831825943900161"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/shortl2021/lists/1445202251128131586"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/iBurnTheta/lists/1443381274647932933"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/lazioannidis/lists/1443246522976571406"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/gabaptista86/lists/1443054567902613504"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ProfessorHt/lists/1442225044785143809"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Z53871932/lists/1440308641068843015"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/sgourosnick88/lists/1440284752737570830"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/rplunk9/lists/1439719669594787848"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/JapaneseMind/lists/1439550351770746882"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/HeyAlbert/lists/1439217653369933824"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/GreenZenForest/lists/1439068560555331585"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/austinnoronha/lists/1437367502535684097"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/_pareil/lists/1435412104643637253"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/questbytate/lists/1434829266059997185"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/neuracap/lists/1434013171962957825"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/fakt13/lists/1433868139746451459"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/TimurZolkin/lists/1431861845959249925"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ConwayYen/lists/1431848450484756488"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ESGQuant/lists/1430705300617584640"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/luyongci/lists/1430300954910334979"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/victor_epelbaum/lists/1428492969150144512"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/j_ng09/lists/1427422619918376961"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mayank2011/lists/1427179558986416131"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SwissQuant/lists/1426877372066844675"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/FoodieFinancier/lists/1426352220124110848"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ratanlalmahanta/lists/1425769746289496070"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Morgann_Grace/lists/1425663464106860545"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jake_burden_/lists/1425644882106798086"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/RunTillDone/lists/1425378484025655297"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ChrisCo81267072/lists/1423908148637753345"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/NtrnFlxLbs28/lists/1421136855303655439"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/atalantis7/lists/1420836236982378498"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/PradyuPrasad/lists/1420353074665717762"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ptrckbrwnng/lists/1420039793493356544"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ptrckbrwnng/lists/1420032300415340544"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/trendwhizo/lists/1419701103193690113"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ow223/lists/1419607441352822785"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/YHRW80/lists/1419570212920336395"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/_BlockTrader_/lists/1419294405790474241"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/anxiuluo/lists/1418806706570727425"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/LindenbergNando/lists/1417837192437813253"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/NAWest1/lists/1417256513467523073"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Houziren/lists/1413716112814993411"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/shortl2021/lists/1413473378992803841"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/sid_void/lists/1412040812876242949"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BenFrankGates2/lists/1411721377170608134"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/shhennronn/lists/1411297597508124677"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/sebareca/lists/1407439124819292160"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/thomasmooney/lists/1406809166371561478"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/merliontango/lists/1405819862581055493"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/trading_cats/lists/1403696740704964608"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nikitium/lists/1403419861708152832"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/maddogmike424/lists/1401954922040549386"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Adrian_H/lists/1401221799854157824"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/pushkarchaudhry/lists/1401062218075017217"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/kekcryptokek/lists/1400982895070793729"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Shawn_X_Tai/lists/1400013666431295490"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/RamHirsch/lists/1399818246380044290"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MPHTrades/lists/1399465870079016964"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/yxk001/lists/1398984964352483329"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/42macroDDale/lists/1398263354918064132"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Nicolasmillerr/lists/1398072748510003200"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/RabbitFire2/lists/1397926383335079953"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MuijsBob/lists/trading-27471"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Laeeth/lists/quant-20626"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tom_markets/lists/vols-11121"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/michellevarron/lists/crypto-48453"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/HafiIntisar/lists/vol-23728"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Padrinho____/lists/estudo-18698"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/XCRISS01/lists/volatility-experts-15168"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/StonksKitty/lists/list-30727"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CYoungtsen/lists/hsbc-list-21066"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ashleyfox4/lists/vol-list-90317"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ParisDakar00/lists/volatility-experts-10034"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/HughG000/lists/voltwit-18072"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BoJackTrader/lists/am-fx-fintwit-10068"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/clint_s_howard/lists/vol-83977"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/beeeyezack/lists/hsbc-am-fx-volatility-12903"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/gannonbreslin/lists/hsbc-fintwit-list-16141"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/TruthFinance/lists/volatility-expert-15067"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DPIII_/lists/hsbc-12106"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jaycee393/lists/fintwit-volatility-index-10304"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tmbotto/lists/vol-12457"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/yoloquant/lists/volatility-24996"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DanSaraujo/lists/vol-is-life-11046"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/javdiaz489/lists/wsb-76014"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/anarion09/lists/volatility-experts-16487"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/GuDaphne/lists/volatilities-14570"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/RuaridhMacK/lists/volatility-19734"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MikeChurchLdn/lists/macro-20697"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SamuelH91149050/lists/reading-16191"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Ldawsonza/lists/top-dogs-11803"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/lumierang/lists/vix-14289"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/reallylongbond/lists/voltwit-13399"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/efffdeeedeee/lists/voltwit-13076"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Akshay_KPandey/lists/foreign-12969"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/chrishsh/lists/quant-and-fintech-15136"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Rob_SF0/lists/list-58958"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/elastochastic/lists/macro-74309"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Smarty__Mcfly/lists/vol-21919"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/eigenvictor95/lists/pms-14201"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/RadonNikodym2/lists/fintwit-18352"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/hazelnutter/lists/filtered-finance-40787"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/aibofren/lists/fintwit-39692"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ACClaw/lists/vol-81298"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Mononokeynes/lists/fintwit-17093"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/firoozye/lists/finance-66985"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/bertverrycken/lists/invest-curated-14138"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ndufour/lists/fin-stuff-21446"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mazi1ne/lists/forex-traders-community-24171"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Beyond_Gudness/lists/options-18032"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/riveranomics/lists/teams-2-0-25402"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/oferlitver/lists/quantitative-trading-13166"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/cilantromurphy1/lists/trader-folk-60104"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ilan15012195/lists/educational-trading-21802"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/OFernau/lists/traders-19228"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jacksonthies/lists/vol-87611"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/VolatilityTrad1/lists/volatility-65792"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ianthetechie/lists/voltwit-25854"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/vlady777/lists/options-futures-vol-20449"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BlackFlagMacro/lists/vol-14890"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/PunkEngineer/lists/000-96395"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Duderichy/lists/informative-11205"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/RightNowxx/lists/heye-news-18392"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Moomin18868107/lists/finance-12869"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/fozlolah/lists/stonks-57340"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BlackFlagMacro/lists/macro-97322"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jamaxiEx/lists/rising-s-fbep-12979"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ltgrant/lists/markets-17827"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/minimarkerr/lists/vol-11464"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/viniciusprandi/lists/fin-us-10731"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Vini_Maximus/lists/read-89122"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/PureSpec_/lists/vol-14416"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/lyNxRG/lists/finan-as-96808"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CommodoreAIO/lists/quant-vol-trading-39296"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/falconzyx/lists/volitility-33867"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/bmichell/lists/trade-15-71077"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/eigenvictor95/lists/us-coverage-42940"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/chadtrade99/lists/trading-20226"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/danielgeorge084/lists/bond-10013"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/marcusbernd/lists/kryptotweets-of-trust-30773"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/JibreelQHameed/lists/market-news-15991"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CooperReed10/lists/finance-bets-24456"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ecebuzz/lists/ideas-14597"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Finlipp/lists/jam-croissant-48335"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/EarlybirdNfts/lists/higherhighs-twubbler-14018"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MG_Macro/lists/macro-17643"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/spiderman_cap/lists/macro-11872"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/_shahmet/lists/finance-77495"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CFA_Life/lists/awesome-world-dominators-37983"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/notanthonylee/lists/finance-10399"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/guilherme_27th/lists/fin-15133"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/TinyDomain/lists/stock-lists-16191"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/invyieldcurve/lists/markets-11394"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nayaitscool/lists/pulse-51119"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nope_its_lily/lists/great-follows-11911"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/KrisAbdelmessih/lists/vol-twitter-pros-only-55050"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jackyehyo/lists/convexity-72446"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/alexhwang82612/lists/vol-macro-34125"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/IsidoreSmart1/lists/rates-fx-24671"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DenysLuzin/lists/macro-30422"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/strongway/lists/market-26832"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/vanshkumar95/lists/top-66501"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/VIXMan15/lists/fin-97044"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nrkmoran/lists/quant-10583"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/namorama1/lists/macro-vol-21276"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ShibeiG/lists/tech-76884"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nolesfan2011/lists/stonks-90901"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/M3kw9/lists/fintwit-18862"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/WacekG/lists/vol-10621"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/alpha19022/lists/quant-15269"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/eborgesjr/lists/quant-19460"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/watsonwati/lists/options-vol-10368"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/f1uffy61/lists/macro-59257"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/kate10010/lists/finance-12147"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/yikesaccount/lists/fintwit-favs-13508"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/rwdrbr/lists/aaa-fixed-income-14205"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mapochamp/lists/notifs-59479"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Xiubur/lists/fintwit-18793"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Donkeisiel/lists/the-greats-39784"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jusqtm/lists/fintwit-15869"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Waitinforthebus/lists/investing-12909"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/chasedodge/lists/doom-squad-20455"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/georgekonio/lists/stocks-commodities-11746"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mike3141592653/lists/stonk-75460"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mzb__o_o_/lists/full-margin-18137"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/VitorDdeAngelis/lists/markets-stuff-13379"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/FinancialAlex/lists/hedgeye-82185"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/IRunWithBulls/lists/them-vixens-53889"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/johnnyloff/lists/oracles-13616"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Sivvson/lists/quant-39671"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/frankcostanza94/lists/fintwit-elite-20242"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ErikasKabak/lists/finance-55224"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/LITERAL_ARTIST_/lists/trades-21746"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/frankqperson/lists/markets-82116"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tf2300/lists/quant-vol-49786"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/howey_feelin/lists/to-follow-10816"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/joaoluizsg/lists/quant-73779"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/dodgerroger/lists/voltwit-10687"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/lt_investor/lists/volatility-70381"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/davewmyers/lists/fixedincome-10238"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DavideNatale/lists/vol-12834"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/residualclaim/lists/only-vega-15286"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/sunrisevol/lists/vol-13878"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/edmtthws/lists/traders-quants-17894"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SopranoCapital/lists/omx-22836"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/hmmmmokwhynot/lists/fintwit-95164"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/famadeo/lists/quantitative-finance-95341"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/EttuBrute16/lists/top-13559"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/WillClark34/lists/fin-20421"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/automata_studio/lists/quant-10962"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Laspeyres/lists/crypto-19281"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/30005k/lists/market-understanding-31464"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nayanderthal/lists/stonks-12113"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/pttp35100657/lists/fj-11777"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/info_otc/lists/main-13025"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/fmantessof/lists/quant-research-89779"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/thomaspower/lists/a-new-list-2021-65300"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/wlbsr/lists/short-short-15715"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mikevanbus/lists/investing-83209"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jackychim/lists/soaked-market-perception-14836"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/_J_S_C/lists/fintwit-17845"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/fadesandpunts/lists/quant-eqd-45694"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/young_bosnia/lists/trading-insights-54349"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/flute41925764/lists/traders-18155"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/AspynPalatnick/lists/options-15316"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/big_dii/lists/quants-17837"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Pablo_vargas5/lists/finance-ideas-16343"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Pablo_vargas5/lists/finance-ideas-61707"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BenGmacro/lists/systematic-options-16272"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/WTF_WEF2021/lists/fresh-thoughts-81176"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/sadalsvvd/lists/trading-77798"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tweetandawe/lists/volatility-20541"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/VolatilityTrad1/lists/markets-trading-14742"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/atm4jj0000/lists/vol-12526"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ebrugel/lists/buddy-c-11105"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tendieland/lists/fintwits-11946"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/marke_trader/lists/stat-quant-instit-fed-vix-88357"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CahitArf11/lists/best-of-fintwit-66901"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/musingtrader/lists/cg001-17595"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nabil23403133/lists/quant-11987"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ImNotChenny/lists/pm-hf-quant-18658"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ilcontepedro/lists/fintwit-20670"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Benjami75855367/lists/volanalysts-15318"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nihal_chandak/lists/volatility-twitter-12170"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/kai_richard/lists/trading-14502"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/taoofzeus/lists/quant-17945"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/JaimeHerreroRo1/lists/volatilidad-13351"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BvVai/lists/volatility-19369"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CaughtKnife/lists/volatility-feed-11311"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jc_deo/lists/req-d-smart-folk-to-flw-12398"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/WolfVermilion/lists/markets-serious-12428"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Cankles13/lists/quantitative-trading-33541"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/egl5712/lists/makevolatiltygreatagain-13946"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Indraneeldesh/lists/options-and-vol-80960"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/IsidoreSmart1/lists/vol-market-technicals-69725"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/EntropicEdge/lists/bookmarks-18122"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DFin24/lists/allfin-30366"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/r_wallstreet_/lists/algo-trading-17326"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/aroitman/lists/rapid-57381"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/gperetin/lists/fintwit-37022"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/RHighland/lists/volatility-41504"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/FortinLudovic/lists/traders-2-15002"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/aniv_49/lists/trade-ideas-20012"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BenFrankGates2/lists/fintwit-52150"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BrianGilbart/lists/event-m-a-spac-spec-29709"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/prarsh/lists/finance-stocks-89614"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DanishAgg/lists/traders-18510"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/deceusterjoris/lists/vola-17640"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/NTRTNMNT/lists/quant-38482"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nineohnine909/lists/cool-10843"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CahitArf11/lists/fintwit-95031"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/UK_LCC/lists/fintwit-42641"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/gpcap2/lists/jf-quant-spac-16544"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Zeitnot/lists/fin-dealers-gamma-30781"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/shashivelur/lists/fintwit-feed-93616"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/kelp_feeder/lists/alpha-leak-17429"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ProfileTrades/lists/voltwit-15443"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tomrichards78/lists/finance-18041"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SzonyiD/lists/volatility-94959"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Waitinforthebus/lists/crypto-18026"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ConvexlyFoolish/lists/quant-finance-10281"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/LuisCor80246896/lists/math-46855"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/iuliancostan/lists/opening-day-10600"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/hutone/lists/stock-54598"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Space_Wrangler_/lists/fintwit-11669"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/RocketSlinger/lists/slingers-11233"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/LuisCor80246896/lists/stocks-35334"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MsvPrasadmsv/lists/fintwit-60096"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/musingtrader/lists/tradgen001-39352"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/paquibena/lists/some-ideas-20275"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/faracher/lists/econ-98882"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/goytoi/lists/trading-2-15120"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/dirkdiggins/lists/good-stuff-18674"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mapochamp/lists/smart-ppl-15313"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/doogiehausr/lists/important"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ApercusTosh/lists/debt1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SigCharts/lists/stock-news"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/cdbarton/lists/active-traders"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SuperPipsFx/lists/options-and-volatility-10540"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ny_poppa/lists/list"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ferbgood/lists/leer-m-s-tarde"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/chusqui/lists/algo"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/FedwardHyde/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/fxbryt/lists/volatility-options"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ox_trades/lists/resources"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mzmyslow/lists/vol-gang1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/gpcap2/lists/jf-spooz"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mdniai1/lists/trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ebrugel/lists/volatility"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BrianGilbart/lists/digital-assets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/_Cdott/lists/trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/fioremjm/lists/traders-analysts"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/24_hour_moon/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/fractalFinance_/lists/alternate-finance1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ChazManetti/lists/voltwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ApercusTosh/lists/apercu-macro-blite"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/noradio/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/rblue215/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/York__Z/lists/stratosphere-stocks"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/RatesFlow/lists/trade-81929"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/hamiltonmontagu/lists/quants-and-vol"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/oli___b/lists/vol"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SuraSys1/lists/trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/WaltNYC/lists/biz"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/federicocarrone/lists/quants1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/whengeniusfail/lists/options-volatility-11221"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BrainMonkey/lists/new-watchlist"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BrianWa73603359/lists/vol-space"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DOptionsTrader/lists/trading-options-vol-10462"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Versace_Trader/lists/options-quant-quality"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BigAltheDukie/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BigGreenBear99/lists/investing"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/JoeyKoh_/lists/trading-macro"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Ataden/lists/vol"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mzb__o_o_/lists/goats"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/itayfeldman/lists/vol"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/bozothegrey/lists/macro-and-markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/NKendrick/lists/buddy-carter-and-quant"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/kohlirohan/lists/trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ch22_chris/lists/fx"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/louisrv297/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/RamiMayron/lists/markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/fazmemon/lists/new-vol"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Bread_and_Games/lists/macro"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/TevoShabazz/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ApercusTosh/lists/astalloalt"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/TradingTrotter/lists/volatility"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/pvncad/lists/vol-traders-20130"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/kgrove29/lists/quant-trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ZMAng/lists/quant"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/TheCloudSaint/lists/signal"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ApercusTosh/lists/apercus-macro-backup"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/milostosic/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/kennyontheweb/lists/economics"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ZaynX42/lists/science-tech"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/unlearnedhands/lists/trading-16787"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/simonsimon219/lists/thestalwart-0"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/voerch/lists/q"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tcopp/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/luischrisper/lists/finanzas"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jefftakaki/lists/stocks"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/AndorraInvestor/lists/smart"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/morbulut/lists/options"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MattWRobinson/lists/trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/TimurZolkin/lists/machine-learning"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SiimKallas/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/KeemVibes/lists/equities-10153"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/andrewsunu1/lists/subs"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Twitta_Chitta/lists/markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/falufalump/lists/investing"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/reggytrades/lists/stock-chartist"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jbh_twit/lists/sanjuan-trader"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ahsan_khan/lists/stock"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/19_a_singh/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ervnbetty/lists/fintweet"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ExpReturns/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Zhakalakalaka/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ride_on_sr/lists/vix-trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/FireIce29176955/lists/watch"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/TimurZolkin/lists/finance-money-debt"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/gpcap2/lists/jf-daytrade"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/LuisCor80246896/lists/economics"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MacroBacon/lists/macrobacon-20444"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/kdspaul/lists/markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/syst3matix/lists/trading-11918"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/wideclops/lists/add"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/cdbarton/lists/best-trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Shit_Capital/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/egl5712/lists/markets-finance-trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/epsilonhedge/lists/squawk"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/aashiq/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/gxd_atom/lists/rehoboam-61742"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/_Mr_Hall/lists/l1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/saamir/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/RabbiJacob16/lists/volfreaks"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ApercusTosh/lists/econ-macro"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ChrisSpockMD/lists/investing"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mattcsnow/lists/macro"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/TheBobBrue/lists/market-must-reads-61227"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/theprofessor03/lists/volatility-quant"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/V0rin/lists/selected2"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ddiassalazar/lists/fintwit-75-44322"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jonknee/lists/crabtrap-trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tivtom/lists/traders-finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/felipebalass/lists/macro"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/davewmyers/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jackbrowning4/lists/swing-trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/macrodeviations/lists/pms"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SillyPeteyPete/lists/financials"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/TrialsOfFortune/lists/trading-17315"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/billbroadhead/lists/all-stars"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/kinosfault/lists/kabu"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mbaltussen/lists/vol"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/YuryGruz/lists/marketstructure"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Tobias57548276/lists/quant"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/PiQLists/lists/markets-core"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ashrafmansari/lists/finance-economics"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ArdavanH/lists/power-stream"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/millermusing/lists/top-traders1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/JapaneseMind/lists/macro"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/LesQuu/lists/traders"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/sethsmoked/lists/trades"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/HeyAlbert/lists/q1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/HYFRitsJimmy/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Bferrazmarques/lists/mercado1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jeremiahmcneal/lists/market-madness"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/stuiofox/lists/mkt"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/brandonseibert/lists/traders"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Trade_The_Swing/lists/alphaclub"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/GrantStenger/lists/trading-all"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/abhinavd73/lists/money-markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/bnoujaim/lists/vol"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CYoungtsen/lists/econ-and-investment1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Waitinforthebus/lists/economics"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/alex_worktwit/lists/opinions2"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ZoltanTokoli/lists/trade"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/V0rin/lists/selected"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/clemstar/lists/trading-talk"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/midazofol/lists/somnistics-insights-18302"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SlowPorcupine/lists/investing"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/andrewsunu1/lists/faves"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/choffstein/lists/options-volatility"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ApercusTosh/lists/apercus-trader-st"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BrianGilbart/lists/market-wizards"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/trend_value/lists/volatility"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ApercusTosh/lists/apercu-macro"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/billbroadhead/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/steeezynuts/lists/quant"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ApercusTosh/lists/apercu-trader"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nakul66097760/lists/myfintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/lennycap/lists/financial"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/shaneseanshane/lists/economic-news"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/amblingthoughts/lists/ml"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Bandy99999/lists/us-macro1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Abeck15/lists/options-volatility-28368"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/KrisAbdelmessih/lists/vol-traders"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/JulioBarros/lists/fintech"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/artem_dubenko/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Dippusen/lists/traders"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/humplik/lists/trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/saedmyster/lists/macro-and-markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/znewem/lists/quant"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/znewem/lists/econ-macro"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/HeyAlbert/lists/v"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ChartArt_SPX/lists/options"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ChrisWeston_PS/lists/vol"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jorda0mega/lists/investing"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/cihanirmak/lists/economy-related"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Gar8743/lists/a-list-for-new-account"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/littletoosaucy/lists/trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/dangm24/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/HeyAlbert/lists/vol"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ezebirman/lists/economics-and-finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ezebirman/lists/science-and-technology"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/sentiment_s/lists/qv-19326"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/scarypolock666/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jacoheartiga/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MacroTactical/lists/trading-and-context-81320"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CaziqueDePoyais/lists/people-who-think-good-12020"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/merliontango/lists/global-markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/joemcolombo/lists/market"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/psrox/lists/financial-global"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/PBJ2114/lists/x"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/GatheringGwei/lists/traditional-finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/thmzlt/lists/quant"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/danielgeorge084/lists/china-with-live-squawk-13084"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jontait/lists/traders-and-finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/JustmeTV5/lists/fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CJAFGarcia/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/JPhFrey/lists/trading-short-term"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jeffh690/lists/options-futures"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/anxiuluo/lists/markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/adLeccia/lists/fin"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/maxkalzone/lists/algos-quants-17629"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MacShadey/lists/traders"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Malgosia_c/lists/algotrading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BluePuddle4/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/johnpelly/lists/intelligent-investors"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/midtownmacro/lists/macro"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/stevenplace/lists/vol"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/apache_doe/lists/trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/VolatilityWiz/lists/criticaltweets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/HorseInRain/lists/vol"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jennifergreen82/lists/god-traders"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BeingHorizontal/lists/marketssportsthoughts"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MarcoDaSilva/lists/forex"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/VolatilityWiz/lists/can-t-miss-fintwit"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/JermalChandler/lists/volatility"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tanakanhongo/lists/macro-markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BankofVol/lists/banksy-s"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/iAbhishek_/lists/reddit-fin"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MacroholicsAnon/lists/macro-12344"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/darius17t/lists/general-finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Wild_Tiger99/lists/traders"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ChrisWeston_PS/lists/macro"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/millermusing/lists/market-mavens"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/iloveechocolat/lists/neue-liste"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/2p718/lists/quant"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/federicocarrone/lists/economy"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/fedya85/lists/fi-markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/LeanSardine/lists/traders"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/VegaVolgaVanna/lists/top"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/WassingtonPost/lists/quant"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/smkumailakbar/lists/business-trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/smkumailakbar/lists/quant-math-data-sci"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/barkinkarsli/lists/crypto"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nmbersdntlie/lists/investing"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jmup/lists/stonks-78598"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/c_franson/lists/market"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jfhksar88/lists/fav-investment"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/rlucindo/lists/fin"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/KrisAbdelmessih/lists/the-a-list"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tiagolvsantos/lists/market"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/rmcd0/lists/crypto-trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/thoughtverboten/lists/trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mathiasberenger/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/0xJoseth_/lists/makets-20664"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/A_LSG_CAPITAL/lists/volatility"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/rodneymettler/lists/markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/stuffonfire/lists/f3-14553"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/siddharthgotam/lists/quant-trading-systems"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/robertmsanchez/lists/financial-markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MikeCBrothers/lists/speculation"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/moinvirani/lists/crypto-investing-experts"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/bmpamaral/lists/new"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Gloeschi/lists/volatility"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/IAmTrickyEnough/lists/either-witch-or-a-doctor"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Vinceorzzz/lists/vol"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DiggerHS/lists/ws"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MinvstrD/lists/volatility"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/hijodelaretweet/lists/quant"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/i_am_sudonim/lists/traders"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MarcosCarreira/lists/iwf"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/drks91/lists/investing-and-finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tangentstyle/lists/quant"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mhxueshan/lists/quant1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ashthaker1/lists/twitterati-54409"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/azimut205/lists/analysts"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Markets360/lists/vol"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CFAMBAibk/lists/finbizinsightbutnoisychat"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/fvo2006/lists/options"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ffullcircle/lists/quant-this"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/AyoubMo/lists/financegurus-79058"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/architectrader/lists/analysis-2"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Trade_The_Swing/lists/volatility"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SC_Dan_W/lists/business-finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mhass33/lists/public-markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/CFAMBAibk/lists/qt-algosystmctrdg-statarb"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/chrismorgs/lists/systematic"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tangentstyle/lists/macro"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/KrisAbdelmessih/lists/quant-funds-traders"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/K_B79/lists/data"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/firoozye/lists/compstats-quant-finance-17665"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Skweez/lists/business-investment"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Gloeschi/lists/traders"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/zuppix/lists/daily-feed"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/hwu76/lists/fintwit-79239"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/JaffrayW/lists/quantitative-trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/joshua_j_lim/lists/investing"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jima00/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/baianomauricio/lists/daytradingstocks"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/ChipsSaas/lists/bestofbestinvest"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/_Erik_Nelson/lists/business-stockmarket"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/DMaro28/lists/important"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/zungybungy/lists/quants"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Marketclosure/lists/market-alerts"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/B1ack5wan/lists/mkt"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/_richardlee/lists/trading-investing"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tangentstyle/lists/investors"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/K_B79/lists/investing"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/SKERO2/lists/options"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/stockgeekTV/lists/investing-finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/krugermacro/lists/markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/BirtleyBadBoy/lists/markets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/mohta77/lists/finance-follow"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MadsenSouth/lists/public-investing"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/firoozye/lists/data-science-ml-stats-19049"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MarcosCarreira/lists/quants"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MoolahMitch/lists/investing"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Longmankind/lists/finance"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nilsmu/lists/finance-econ-tech"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/shenno/lists/fxpropure"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jose3ff/lists/trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/hammadhshahir/lists/stocks"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/Hugopvigo/lists/trading"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/tmcgeeney/lists/global-macro"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/joshua_ulrich/lists/quant"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/MacroMojo/lists/vix-trader"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/jamestm0/lists/financemarkets"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/0xf13r/lists/financial-blogs-traders"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/johnpelly/lists/intelligent-investing"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/nmarkoulakis/lists/opts"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/patrickrooney/lists/trading1"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/shenno/lists/equities"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/shawngidley/lists/stocks"
    }
  }
]