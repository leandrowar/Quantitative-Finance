window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "Global Volatility Trading. Python addict. Bloomberg Junkie.Voted 2008 rookie trader of the year. Amateur Boxer and boxing coach (RSB cert.) != investment advice",
        "website" : "https://t.co/PvTK0XMdzc",
        "location" : "Tel Aviv, Israel"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1450851693076357123/tMSFfMFi.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1293505084484132864/1646157315"
    }
  }
]